import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assign } from '../netlify/functions/lib/assign.ts';

test('draws give every participant one unique recipient without self-matches', () => {
  for (let size = 2; size <= 40; size++) {
    const keys = Array.from({ length: size }, (_, i) => `participant_${i}`);
    for (let trial = 0; trial < 20; trial++) {
      const result = assign(keys, keys);
      assert.ok(result);
      assert.equal(result.size, size);
      assert.equal(new Set(result.values()).size, size);
      for (const [target, drawer] of result) assert.notEqual(target, drawer);
    }
  }
});

test('remaining assignments preserve recipients already reserved', () => {
  const result = assign(['a', 'b'], ['a', 'c']);
  assert.ok(result);
  assert.equal(result.get('c'), 'a');
  assert.equal(result.get('a'), 'b');
});

test('impossible and single-person draws cannot assign someone to themselves', () => {
  assert.equal(assign(['a'], ['a']), null);
  assert.equal(assign(['a', 'b'], ['a']), null);
});
