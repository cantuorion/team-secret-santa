import { test } from 'node:test';
import assert from 'node:assert/strict';
import { profileMatches } from '../netlify/functions/lib/profile-matches.ts';

const cards = [
  { key: 'legacy_a', ownerId: null },
  { key: 'legacy_b', ownerId: null },
  { key: 'alice', ownerId: 'profile_a' },
  { key: 'bob', ownerId: 'profile_b' },
];

test('legacy and orphaned draws do not lock profile card registration', () => {
  assert.deepEqual(profileMatches(cards, [
    { drawerKey: 'legacy_a', targetKey: 'legacy_b' },
    { drawerKey: 'missing', targetKey: 'alice' },
    { drawerKey: 'alice', targetKey: 'legacy_a' },
  ]), []);
});

test('real profile draws still lock registration and retain assignments', () => {
  const match = { drawerKey: 'alice', targetKey: 'bob' };
  assert.deepEqual(profileMatches(cards, [
    { drawerKey: 'legacy_a', targetKey: 'legacy_b' }, match,
  ]), [match]);
});
