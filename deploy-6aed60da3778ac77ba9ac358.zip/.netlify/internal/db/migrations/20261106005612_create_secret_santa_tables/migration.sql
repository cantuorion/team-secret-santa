CREATE TABLE "cards" (
	"key" text PRIMARY KEY,
	"name" text NOT NULL,
	"color" text DEFAULT '' NOT NULL,
	"hobbies" text DEFAULT '' NOT NULL,
	"food" text DEFAULT '' NOT NULL,
	"drink" text DEFAULT '' NOT NULL,
	"collection" text DEFAULT '' NOT NULL,
	"gift_type" text DEFAULT '' NOT NULL,
	"timestamp" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "matches" (
	"drawer_key" text PRIMARY KEY,
	"target_key" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "settings" (
	"id" text PRIMARY KEY,
	"draw_locked" boolean DEFAULT true NOT NULL
);
