CREATE TABLE "profiles" (
	"id" text PRIMARY KEY,
	"username" text NOT NULL UNIQUE
);
--> statement-breakpoint
ALTER TABLE "cards" ADD COLUMN "owner_id" text;--> statement-breakpoint
ALTER TABLE "cards" ADD CONSTRAINT "cards_owner_id_key" UNIQUE("owner_id");--> statement-breakpoint
ALTER TABLE "cards" ADD CONSTRAINT "cards_owner_id_profiles_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "profiles"("id");