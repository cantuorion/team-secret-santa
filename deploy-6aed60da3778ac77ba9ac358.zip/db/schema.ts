import { pgTable, text, bigint, boolean } from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: text().primaryKey(),
  username: text().notNull().unique(),
});

export const cards = pgTable("cards", {
  key: text().primaryKey(),
  ownerId: text("owner_id").unique().references(() => profiles.id),
  name: text().notNull(),
  color: text().notNull().default(""),
  hobbies: text().notNull().default(""),
  food: text().notNull().default(""),
  drink: text().notNull().default(""),
  collection: text().notNull().default(""),
  giftType: text("gift_type").notNull().default(""),
  timestamp: bigint({ mode: "number" }).notNull(),
});

export const matches = pgTable("matches", {
  drawerKey: text("drawer_key").primaryKey(),
  targetKey: text("target_key").notNull(),
});

export const settings = pgTable("settings", {
  id: text().primaryKey(),
  drawLocked: boolean("draw_locked").notNull().default(true),
});
