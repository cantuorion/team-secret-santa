import { assign } from "./lib/assign.ts";
import { profileMatches } from "./lib/profile-matches.ts";
import type { PoolClient } from "pg";
import type { Config } from "@netlify/functions";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { eq, or } from "drizzle-orm";
import { admin as identityAdmin, login, logout, getUser, refreshSession, verifyRequestOrigin, AuthError } from "@netlify/identity";
import { getDatabase } from "@netlify/database";
import { db } from "../../db/index.js";
import { cards, matches, settings, profiles } from "../../db/schema.js";

type CardInput = {
  name?: unknown;
  color?: unknown;
  hobbies?: unknown;
  food?: unknown;
  drink?: unknown;
  collection?: unknown;
  giftType?: unknown;
  timestamp?: unknown;
};

const str = (v: unknown, max = 500) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const toKey = (name: string) => name.toLowerCase().replace(/[^a-z0-9]/g, "_");

function toRow(key: string, input: CardInput) {
  return {
    key,
    name: str(input.name, 100),
    color: str(input.color),
    hobbies: str(input.hobbies),
    food: str(input.food),
    drink: str(input.drink),
    collection: str(input.collection),
    giftType: str(input.giftType),
    timestamp: typeof input.timestamp === "number" ? input.timestamp : Date.now(),
  };
}

async function getState(req: Request) {
  const user = await getUser();
  const [profile] = user ? await db.select().from(profiles).where(eq(profiles.id, user.id)) : [];
  const [cardRows, matchRows, settingRows] = await Promise.all([
    db.select().from(cards).orderBy(cards.timestamp),
    db.select().from(matches),
    db.select().from(settings).where(eq(settings.id, "global")),
  ]);
  const cardMap: Record<string, Omit<typeof cardRows[number], "key" | "ownerId">> = {};
  for (const { key, ownerId, ...rest } of cardRows) cardMap[key] = rest;
  const matchMap: Record<string, string> = {};
  const ownCard = cardRows.find(c => c.ownerId === profile?.id);
  const activeMatches = profileMatches(cardRows, matchRows);
  for (const m of activeMatches) {
    if (isAdmin(req) || m.drawerKey === ownCard?.key) matchMap[m.drawerKey] = m.targetKey;
  }
  return {
    cardsLocked: activeMatches.length > 0,
    profile: profile ? { username: profile.username, cardKey: ownCard?.key ?? null } : null,
    cards: cardMap,
    matches: matchMap,
    drawLocked: settingRows[0]?.drawLocked ?? true,
  };
}

class ProtectedCardsError extends Error {}

async function replaceCards(input: Record<string, CardInput>) {
  const protectedCards = await db.select().from(cards);
  if (protectedCards.some(c => c.ownerId)) throw new ProtectedCardsError("Sample data and replacement imports cannot overwrite profile-owned cards.");
  const rows = Object.entries(input)
    .map(([key, c]) => toRow(toKey(key) || toKey(str(c.name)), c))
    .filter((r) => r.key && r.name);
  await db.delete(matches);
  await db.delete(cards);
  if (rows.length) await db.insert(cards).values(rows);
}

async function setDrawLocked(locked: boolean) {
  await db
    .insert(settings)
    .values({ id: "global", drawLocked: locked })
    .onConflictDoUpdate({ target: settings.id, set: { drawLocked: locked } });
}

const bad = (msg: string, status = 400) => Response.json({ error: msg }, { status });

// Admin login. Only a SHA-256 hash of "username:password" is kept here, so the
// credentials never appear in the page source. To change them, set the
// ADMIN_USERNAME and ADMIN_PASSWORD environment variables in Netlify.
const DEFAULT_ADMIN_HASH = "c6fa8c0dafb4cdadda0180f25c585c73c436b809050e10b203fa133a5e083525";
const sha256 = (v: string) => createHash("sha256").update(v).digest("hex");

function adminHash() {
  const u = process.env.ADMIN_USERNAME;
  const p = process.env.ADMIN_PASSWORD;
  return u && p ? sha256(`${u}:${p}`) : DEFAULT_ADMIN_HASH;
}

const sessionToken = () => createHmac("sha256", adminHash()).update("viper-admin-session").digest("hex");

function safeEqual(a: string, b: string) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

function isAdmin(req: Request) {
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  return !!token && safeEqual(token, sessionToken());
}

export default async (req: Request) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
  const [resource, id] = parts;
  const method = req.method;

  try {
    if (!["GET", "HEAD"].includes(method)) verifyRequestOrigin(req);
    await refreshSession();
    if (resource === "profile" && method === "GET") {
      return Response.json((await getState(req)).profile);
    }
    if (resource === "profile" && ["signup", "login"].includes(id) && method === "POST") {
      const body = await req.json();
      const username = typeof body.username === "string" ? body.username.trim().toLowerCase() : "";
      const password = body.password;
      if (!/^[a-z0-9_]{3,30}$/.test(username)) return bad("Use 3–30 letters, numbers, or underscores for your username.");
      if (typeof password !== "string" || password.length < 8 || password.length > 128) return bad("Use a password between 8 and 128 characters.");
      // Identity requires an address internally; participants only supply a username.
      const address = `${sha256(username)}@profiles.invalid`;
      if (id === "signup") {
        const user = await identityAdmin.createUser({ email: address, password });
        await db.insert(profiles).values({ id: user.id, username }).onConflictDoNothing();
      }
      const user = await login(address, password);
      await db.insert(profiles).values({ id: user.id, username }).onConflictDoNothing();
      return Response.json({ username });
    }
    if (resource === "profile" && id === "logout" && method === "POST") {
      await logout();
      return new Response(null, { status: 204 });
    }
    if (resource === "login" && method === "POST") {
      const { username, password } = (await req.json()) as { username?: unknown; password?: unknown };
      const attempt = sha256(`${str(username, 200)}:${typeof password === "string" ? password : ""}`);
      if (!safeEqual(attempt, adminHash())) return bad("Invalid username or password", 401);
      return Response.json({ token: sessionToken() });
    }

    if (resource === "session" && method === "GET") {
      return Response.json({ admin: isAdmin(req) });
    }

    const adminOnly =
      (resource === "cards" && id === "sample" && method === "POST") ||
      (resource === "cards" && id && method === "DELETE") ||
      (resource === "matches" && method === "DELETE") ||
      resource === "draw-lock" ||
      resource === "import";
    if (adminOnly && !isAdmin(req)) return bad("Admin login required", 401);

    if (resource === "state" && method === "GET") {
      return Response.json(await getState(req), { headers: { "Cache-Control": "private, no-store" } });
    }

    if (resource === "cards" && id === "sample" && method === "POST") {
      const body = (await req.json()) as Record<string, CardInput>;
      await replaceCards(body);
      return Response.json(await getState(req), { headers: { "Cache-Control": "private, no-store" } });
    }

    if (resource === "cards" && method === "POST") {
      const user = await getUser();
      if (!user) return bad("Sign in to your profile before creating a card.", 401);
      const [profile] = await db.select().from(profiles).where(eq(profiles.id, user.id));
      if (!profile) return bad("Profile required", 403);
      const body = (await req.json()) as CardInput;
      const row = toRow(`profile_${user.id}`, { ...body, timestamp: Date.now() });
      if (!row.name) return bad("Name is required");
      const client = await getDatabase().pool.connect() as unknown as PoolClient;
      try {
        await client.query("BEGIN");
        await client.query("LOCK TABLE cards, matches, settings IN SHARE ROW EXCLUSIVE MODE");
        const drawn = await client.query(`SELECT 1 FROM matches m
          JOIN cards d ON d.key = m.drawer_key
          JOIN cards t ON t.key = m.target_key
          WHERE d.owner_id IS NOT NULL AND t.owner_id IS NOT NULL LIMIT 1`);
        if (drawn.rows.length) {
          await client.query("ROLLBACK");
          return bad("Cards are locked after drawing begins.", 403);
        }
        await client.query(`INSERT INTO cards (key, owner_id, name, color, hobbies, food, drink, collection, gift_type, timestamp)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
          ON CONFLICT (owner_id) DO UPDATE SET name=EXCLUDED.name, color=EXCLUDED.color,
          hobbies=EXCLUDED.hobbies, food=EXCLUDED.food, drink=EXCLUDED.drink,
          collection=EXCLUDED.collection, gift_type=EXCLUDED.gift_type`,
          [row.key, user.id, row.name, row.color, row.hobbies, row.food, row.drink, row.collection, row.giftType, row.timestamp]);
        await client.query("COMMIT");
        return Response.json({ key: row.key }, { status: 201 });
      } catch (error) { await client.query("ROLLBACK"); throw error; }
      finally { client.release(); }
    }

    if (resource === "cards" && id && method === "DELETE") {
      const assigned = await db.select().from(matches).where(or(eq(matches.drawerKey, id), eq(matches.targetKey, id)));
      if (assigned.length) return bad("Reset draws before deleting an assigned card.", 409);
      await db.delete(cards).where(eq(cards.key, id));
      return new Response(null, { status: 204 });
    }

    if (resource === "matches" && method === "POST") {
      const user = await getUser();
      if (!user) return bad("Sign in to draw your match.", 401);
      const client = await getDatabase().pool.connect() as unknown as PoolClient;
      try {
        await client.query("BEGIN");
        await client.query("LOCK TABLE cards, matches, settings IN SHARE ROW EXCLUSIVE MODE");
        const all = (await client.query<{ key: string; owner_id: string | null }>("SELECT key, owner_id FROM cards WHERE owner_id IS NOT NULL")).rows;
        const own = all.find(c => c.owner_id === user.id);
        if (!own) { await client.query("ROLLBACK"); return bad("Create your card first.", 403); }
        const existing = (await client.query<{ drawer_key: string; target_key: string }>(`SELECT m.drawer_key, m.target_key FROM matches m
          JOIN cards d ON d.key = m.drawer_key
          JOIN cards t ON t.key = m.target_key
          WHERE d.owner_id IS NOT NULL AND t.owner_id IS NOT NULL`)).rows;
        const saved = existing.find(m => m.drawer_key === own.key);
        if (saved) { await client.query("COMMIT"); return Response.json({ drawerKey: own.key, targetKey: saved.target_key }); }
        const lock = (await client.query("SELECT draw_locked FROM settings WHERE id='global'")).rows[0];
        if (lock?.draw_locked !== false) { await client.query("ROLLBACK"); return bad("Drawing is currently locked", 403); }
        const pending = all.filter(c => !existing.some(m => m.drawer_key === c.key));
        const targets = all.filter(c => !existing.some(m => m.target_key === c.key)).map(c => c.key);
        const assigned = assign(pending.map(c => c.key), targets);
        if (!assigned) {
          await client.query("ROLLBACK"); return bad("At least two participants and a complete set of available matches are required.", 409);
        }
        let targetKey = "";
        for (const [target, drawer] of assigned) {
          await client.query("INSERT INTO matches (drawer_key,target_key) VALUES ($1,$2)", [drawer, target]);
          if (drawer === own.key) targetKey = target;
        }
        await client.query("COMMIT");
        return Response.json({ drawerKey: own.key, targetKey });
      } catch (error) { await client.query("ROLLBACK"); throw error; }
      finally { client.release(); }
    }

    if (resource === "matches" && method === "DELETE") {
      await db.delete(matches);
      return new Response(null, { status: 204 });
    }

    if (resource === "draw-lock" && method === "PUT") {
      const { locked } = (await req.json()) as { locked?: unknown };
      await setDrawLocked(locked !== false);
      return Response.json({ drawLocked: locked !== false });
    }

    if (resource === "import" && method === "POST") {
      const body = (await req.json()) as {
        cards?: Record<string, CardInput>;
        matches?: Record<string, string>;
        drawLocked?: boolean;
      };
      if (!body.cards || typeof body.cards !== "object") return bad("Invalid backup file");
      await replaceCards(body.cards);
      const matchRows = Object.entries(body.matches ?? {})
        .filter(([d, t]) => typeof t === "string" && body.cards![d] && body.cards![t])
        .map(([drawerKey, targetKey]) => ({ drawerKey, targetKey }));
      if (matchRows.length) await db.insert(matches).values(matchRows);
      await setDrawLocked(body.drawLocked !== false);
      return Response.json(await getState(req), { headers: { "Cache-Control": "private, no-store" } });
    }

    return bad("Not found", 404);
  } catch (err) {
    if (err instanceof ProtectedCardsError) return bad(err.message, 409);
    if (err instanceof AuthError) return bad(resource === "profile" && id === "signup" ? "Could not create profile. This username may already be taken." : "Invalid username or password.", 400);
    console.error("API request failed");
    return bad("Server error", 500);
  }
};

export const config: Config = {
  path: "/api/*",
};
