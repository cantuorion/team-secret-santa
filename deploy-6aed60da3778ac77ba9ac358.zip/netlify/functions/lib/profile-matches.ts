// Legacy cards have no owner and are outside the profile-based exchange.
export function profileMatches<T extends { drawerKey: string; targetKey: string }>(
  cards: { key: string; ownerId: string | null }[],
  matches: T[],
): T[] {
  const participants = new Set(cards.filter(card => card.ownerId !== null).map(card => card.key));
  return matches.filter(match => participants.has(match.drawerKey) && participants.has(match.targetKey));
}
