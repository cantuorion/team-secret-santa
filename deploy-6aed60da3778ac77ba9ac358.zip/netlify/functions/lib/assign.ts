import { randomInt } from "node:crypto";

// Complete a one-to-one draw while preserving previously stored assignments.
export function assign(pending: string[], available: string[]): Map<string, string> | null {
  const targets = [...available];
  for (let i = targets.length - 1; i > 0; i--) { const j = randomInt(i + 1); [targets[i], targets[j]] = [targets[j], targets[i]]; }
  const assigned = new Map<string, string>();
  function place(drawer: string, seen: Set<string>): boolean {
    for (const target of targets) {
      if (target === drawer || seen.has(target)) continue;
      seen.add(target);
      const previous = assigned.get(target);
      if (!previous || place(previous, seen)) { assigned.set(target, drawer); return true; }
    }
    return false;
  }
  return pending.every(key => place(key, new Set())) ? assigned : null;
}
